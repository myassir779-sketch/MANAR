# Translation quality feature

No quality score is displayed. A future quality workflow should use documented evaluation sets and human review; do not claim 100% accuracy or invent percentage scores. Back-translation alone is not proof of correctness.
