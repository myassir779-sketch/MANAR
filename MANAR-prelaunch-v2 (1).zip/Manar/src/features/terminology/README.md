# Terminology feature

Phase 1 provides a personal glossary. Automatic term preservation in translation is not implemented because no translation model is connected. Future integration must test terminology handling rather than assume glossary entries affect output.
