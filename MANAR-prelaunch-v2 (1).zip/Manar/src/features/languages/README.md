# Language registry feature

The current interface language registry is `src/config/languages.js`. Its entries describe selector labels only; `translationReady` is false for every language. Add support only with a verified source/target pair and model evidence documented in `MODEL_LICENSES.md` and `docs/SUPPORTED_LANGUAGES.md`.
