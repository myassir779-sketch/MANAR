# Settings feature

Current controls cover source text size, opt-in history preference, and clearing local glossary/history data. Settings are browser-local. More settings should be added only when they affect implemented functionality.
