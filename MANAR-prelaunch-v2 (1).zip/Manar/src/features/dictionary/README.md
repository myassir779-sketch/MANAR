# Glossary feature

Implemented in the browser UI with `localStorage`. Entries are rendered using DOM text nodes/textContent rather than HTML interpolation. Browser storage is not encrypted and must not be used for secrets.
