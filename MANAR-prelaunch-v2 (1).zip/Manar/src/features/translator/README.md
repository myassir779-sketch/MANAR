# Translator feature

The UI is in `index.html`; translation orchestration lives in `src/services/translation/translator.js`. Phase 1 deliberately returns an explicit `ENGINE_UNAVAILABLE` result for all pairs. Add a model adapter only after license, runtime, language direction, download size, and quality tests are documented. Never substitute dictionary replacements or generated placeholder text for translation.
