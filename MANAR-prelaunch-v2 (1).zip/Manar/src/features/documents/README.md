# Document translation feature

Not implemented. Future support must be added one format at a time, with file type/size validation, explicit privacy notices, format-preservation tests, and documented library licenses. Do not claim PDF/DOCX support before testing.
