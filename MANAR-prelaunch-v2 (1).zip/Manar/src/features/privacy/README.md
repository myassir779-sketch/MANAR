# Privacy feature

See `PRIVACY.md`. Translation input remains in the page in Phase 1. The optional font import in the stylesheet can contact Google Fonts; remove it for a stricter no-third-party-request mode.
