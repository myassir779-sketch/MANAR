# History feature

The UI stores a local preference for history, but Phase 1 does not save translation records because there are no verified translation results. If history is implemented later, make it opt-in, local-first, searchable, deletable, and clear about browser storage limitations.
