/** Reports browser-reported connectivity only; does not make network requests. */
export function getConnectivityStatus(navigatorLike = globalThis.navigator) {
  if (!navigatorLike || typeof navigatorLike.onLine !== 'boolean') return 'unknown';
  return navigatorLike.onLine ? 'online' : 'offline';
}
