/** Safe placeholder boundary: no model downloads occur in Phase 1. */
export async function loadTranslationModel(modelId) {
  if (!modelId) return { ok: false, code: 'MODEL_ID_REQUIRED' };
  return { ok: false, code: 'MODEL_NOT_CONFIGURED', modelId, message: 'No reviewed model is configured; no download was started.' };
}
