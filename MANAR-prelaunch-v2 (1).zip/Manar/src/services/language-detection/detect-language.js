/** Language detection is intentionally unavailable until a verified detector is integrated. */
export async function detectLanguage(text) {
  if (!String(text ?? '').trim()) return { ok: false, code: 'EMPTY_INPUT', language: null };
  return { ok: false, code: 'DETECTOR_UNAVAILABLE', language: null, message: 'Automatic language detection is not configured.' };
}
