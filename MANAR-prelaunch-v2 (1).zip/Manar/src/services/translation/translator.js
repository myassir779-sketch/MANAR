import { getLanguageLabel } from '../../config/languages.js';

/** Calls only the same-origin MANAR local bridge. Never falls back to fabricated output. */
export async function translateText({ text, sourceLanguage, targetLanguage }) {
  const input = String(text ?? '').trim();
  if (!input) return { ok: false, code: 'EMPTY_INPUT', message: 'Weka maandishi ya kutafsiri kwanza.' };
  if (input.length > 50000) return { ok: false, code: 'TEXT_TOO_LONG', message: 'Kikomo ni herufi 50,000 kwa ombi.' };
  if (sourceLanguage !== 'auto' && sourceLanguage === targetLanguage) {
    return { ok: false, code: 'SAME_LANGUAGE', message: 'Chagua lugha mbili tofauti.' };
  }
  if (sourceLanguage === 'auto') {
    return { ok: false, code: 'DETECTION_UNAVAILABLE', message: 'Utambuzi wa lugha haujaunganishwa. Chagua lugha ya chanzo mwenyewe.' };
  }
  try {
    const response = await fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: input, sourceLanguage, targetLanguage }),
      signal: AbortSignal.timeout(120000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data.ok !== true || typeof data.translation !== 'string') {
      return { ok: false, code: data.error || 'ENGINE_UNAVAILABLE', message: data.message || `Tafsiri haipatikani kwa ${getLanguageLabel(sourceLanguage)} → ${getLanguageLabel(targetLanguage)}.` };
    }
    return { ok: true, translation: data.translation, engine: data.engine || 'Local engine' };
  } catch (error) {
    return { ok: false, code: 'LOCAL_SERVER_UNAVAILABLE', message: 'MANAR local server haipatikani. Endesha `python server.py` kisha fungua http://127.0.0.1:4173. Hakuna maandishi yaliyotumwa kwa huduma ya nje.' };
  }
}
