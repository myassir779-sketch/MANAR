export const MAX_SOURCE_CHARACTERS = 5000;

export function normalizeInput(value) {
  return String(value ?? '').replace(/\r\n?/g, '\n').trim();
}

export function countCharacters(value) {
  return String(value ?? '').length;
}

export function validateSourceText(value) {
  const text = String(value ?? '');
  if (!text.trim()) return { ok: false, code: 'EMPTY_INPUT' };
  if (text.length > MAX_SOURCE_CHARACTERS) return { ok: false, code: 'INPUT_TOO_LONG' };
  return { ok: true, code: 'OK' };
}
