import { LANGUAGES, getLanguageLabel } from './config/languages.js';
import { translateText } from './services/translation/translator.js';

(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const KEYS = {
    projects:'manar.projects.v2', memory:'manar.memory.v2', glossary:'manar.glossary.v2',
    history:'manar.history.v2', historyEnabled:'manar.historyEnabled.v2', audit:'manar.audit.v2',
    textSize:'manar.textSize.v2', output:'manar.output.v2', languages:'manar.uiLanguages.v2',
    translators:'manar.translators.v1', organizations:'manar.organizations.v1', jobs:'manar.jobs.v1'
  };
  const safeRead = (key, fallback) => { try { const value = localStorage.getItem(key); return value === null ? fallback : JSON.parse(value); } catch { return fallback; } };
  const safeWrite = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; } };
  const state = {
    view:'translator', textSize:Number(safeRead(KEYS.textSize,15)) || 15,
    historyEnabled:safeRead(KEYS.historyEnabled,false) === true,
    history:safeRead(KEYS.history,[]), glossary:safeRead(KEYS.glossary,[]),
    memory:safeRead(KEYS.memory,[]), projects:safeRead(KEYS.projects,[]), audit:safeRead(KEYS.audit,[]),
    translators:safeRead(KEYS.translators,[]), organizations:safeRead(KEYS.organizations,[]), jobs:safeRead(KEYS.jobs,[]),
    output:safeRead(KEYS.output,'')
  };
  const labels = {
    translator:'Tafsiri', documents:'Nyaraka & faili', projects:'Miradi', translators:'Watafsiri / Waajiri', organizations:'Mashirika', jobinbox:'Kazi zinazoingia', memory:'Translation memory',
    dictionary:'Istilahi / Glossary', quality:'Ukaguzi wa ubora', subtitles:'Zana za subtitles',
    texttools:'Zana za maandishi', history:'Historia ya kazi', admin:'Admin console',
    settings:'Mipangilio & faragha', help:'Msaada & kuhusu MANAR'
  };
  const langName = getLanguageLabel;
  let toastTimer;
  function toast(message) {
    const el = $('toast'); if (!el) return;
    el.textContent = message; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
  }
  function status(message) { if ($('status-message')) $('status-message').textContent = message; toast(message); }
  function persist(key, value) { if (!safeWrite(key,value)) { toast('Hifadhi imeshindikana. Storage ya browser inaweza kuwa imejaa.'); return false; } return true; }
  function audit(action, detail='') {
    state.audit.unshift({id:cryptoId(),action,detail,at:new Date().toISOString()});
    state.audit = state.audit.slice(0,150); persist(KEYS.audit,state.audit);
    if (state.historyEnabled) {
      state.history.unshift({id:cryptoId(),action,detail,at:new Date().toISOString()});
      state.history = state.history.slice(0,200); persist(KEYS.history,state.history);
    }
    renderAudit(); renderAdminStats();
  }
  function cryptoId() { return (globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,9)}`); }
  function escCsv(value) { return `"${String(value ?? '').replaceAll('"','""')}"`; }
  function download(filename, content, type='text/plain;charset=utf-8') {
    const blob = new Blob([content],{type}); const url = URL.createObjectURL(blob);
    const a=document.createElement('a'); a.href=url; a.download=filename; document.body.append(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function showView(view) {
    if (!labels[view]) view='translator';
    state.view=view;
    document.querySelectorAll('.view').forEach(el=>el.classList.add('hidden'));
    $('view-'+view)?.classList.remove('hidden');
    document.querySelectorAll('.nav-item[data-view]').forEach(btn=>btn.classList.toggle('active',btn.dataset.view===view));
    $('page-title').textContent=labels[view];
    if (view==='history') renderHistory();
    if (view==='dictionary') renderGlossary();
    if (view==='memory') renderMemory();
    if (view==='projects') renderProjects();
    if (view==='translators') renderTranslators();
    if (view==='organizations') renderOrganizations();
    if (view==='jobinbox') { renderJobs(); refreshOrganizationOptions(); }
    if (view==='admin') { renderAdminStats(); renderAudit(); renderAdminLanguages(); }
    if (view==='settings') $('history-enabled-settings').checked=state.historyEnabled;
  }
  document.querySelectorAll('.nav-item[data-view]').forEach(btn=>btn.addEventListener('click',()=>showView(btn.dataset.view)));
  document.querySelectorAll('[data-go]').forEach(btn=>btn.addEventListener('click',()=>showView(btn.dataset.go)));
  $('year').textContent=new Date().getFullYear();

  // Language selectors: visible choices are not claims that translation is available.
  const languageOptions=LANGUAGES.filter(x=>x.code!=='auto');
  function fillLanguages(select, includeAuto=false) {
    if (!select) return;
    select.replaceChildren();
    if (includeAuto) { const auto=document.createElement('option'); auto.value='auto'; auto.textContent='Tambua lugha'; select.append(auto); }
    languageOptions.forEach(lang=>{const option=document.createElement('option');option.value=lang.code;option.textContent=lang.name;select.append(option);});
  }
  fillLanguages($('source-language'),true); fillLanguages($('target-language'));
  $('source-language').value='auto'; $('target-language').value='sw';
  fillLanguages($('project-source')); fillLanguages($('project-target'));
  fillLanguages($('translator-native-language')); fillLanguages($('job-source-language')); fillLanguages($('job-target-language'));
  if ($('job-source-language')) $('job-source-language').value='en';
  if ($('job-target-language')) $('job-target-language').value='sw';
  $('project-source').value='en'; $('project-target').value='sw';

  const source=$('source-text'), output=$('translation-output');
  function updateCounts() {
    const text=source.value;
    $('char-count').textContent=`${text.length.toLocaleString()} herufi`;
    $('word-count').textContent=`${(text.trim().match(/\S+/g)||[]).length.toLocaleString()} maneno`;
  }
  source.addEventListener('input',updateCounts);
  $('swap-languages').addEventListener('click',()=>{
    const from=$('source-language'),to=$('target-language');
    if(from.value==='auto'){status('Chagua lugha ya chanzo kwanza ili kubadilisha lugha.');return;}
    const old=from.value;from.value=to.value;to.value=old;
    const oldText=source.value;source.value=$('editable-output').classList.contains('hidden')?output.textContent:$('editable-output').value;
    if(source.value.includes('Matokeo yataonekana hapa')) source.value=oldText;
    $('editable-output').value=oldText;updateCounts();status('Lugha zimebadilishwa. Kumbuka: injini halisi bado haijaunganishwa.');
  });
  $('clear-text').addEventListener('click',()=>{
    source.value='';output.textContent='Matokeo yataonekana hapa baada ya kuunganishwa kwa injini halisi ya tafsiri.';
    output.classList.remove('has-result');$('editable-output').value='';$('editable-output').classList.add('hidden');output.classList.remove('hidden');
    $('output-note').textContent='Hakuna tafsiri iliyotengenezwa.';updateCounts();status('Maandishi yamefutwa.');
  });
  $('translate-button').addEventListener('click',async()=>{
    const button=$('translate-button');
    if(!source.value.trim()){status('Weka maandishi ya kutafsiri kwanza.');return;}
    button.disabled=true;button.setAttribute('aria-busy','true');button.dataset.originalText=button.textContent;button.textContent='Inatafsiri…';
    try {
      const result=await translateText({text:source.value,sourceLanguage:$('source-language').value,targetLanguage:$('target-language').value});
      if(result.ok){
        output.textContent=result.translation;output.classList.add('has-result');output.classList.remove('hidden');$('editable-output').classList.add('hidden');
        $('editable-output').value=result.translation;$('edit-output').textContent='Hariri matokeo';
        $('output-note').textContent=`Imetafsiriwa na ${result.engine || 'injini ya ndani'}. Hakiki matokeo kabla ya kutumia.`;
        $('engine-label').textContent='INJINI YA NDANI';audit('Translated text',`${$('source-language').value} → ${$('target-language').value}`);status('Tafsiri imekamilika. Tafadhali kagua usahihi wa matokeo.');
      } else { $('output-note').textContent='Hakuna tafsiri iliyotengenezwa.';status(result.message || 'Injini ya tafsiri haipatikani.'); }
    } catch { status('Tafsiri imeshindikana bila kutoa matokeo.'); }
    finally {button.disabled=false;button.removeAttribute('aria-busy');button.textContent='✦ Tafsiri maandishi →';}
  });

  // Detect whether the local translation bridge and any language packages are available.
  async function refreshEngineStatus(){
    const statusEl=$('system-status');
    try {
      const response=await fetch('/api/health',{cache:'no-store'});
      const health=await response.json();
      if(health.engineReady){statusEl.textContent='Local engine ready';$('engine-label').textContent='LOCAL ENGINE';}
      else {statusEl.textContent='Local mode';$('engine-label').textContent='MODELI HAZIPO';}
      $('output-note').textContent=health.message || 'Hali ya injini ya ndani imekaguliwa.';
    } catch {
      statusEl.textContent='UI preview';
    }
  }
  refreshEngineStatus();
  $('copy-output').addEventListener('click',async()=>{
    const text=$('editable-output').classList.contains('hidden')?output.textContent:$('editable-output').value;
    if(!text.trim()||text.startsWith('Matokeo yataonekana hapa')){status('Hakuna matokeo ya kunakili bado.');return;}
    try{await navigator.clipboard.writeText(text);status('Maandishi yamenakiliwa.');}catch{status('Clipboard imezuiwa na browser. Chagua maandishi na unakili mwenyewe.');}
  });
  $('edit-output').addEventListener('click',()=>{
    const editor=$('editable-output');
    if(editor.classList.contains('hidden')){editor.value=output.classList.contains('has-result')?output.textContent:'';editor.classList.remove('hidden');output.classList.add('hidden');$('edit-output').textContent='Hifadhi hariri';editor.focus();}
    else {output.textContent=editor.value;output.classList.toggle('has-result',Boolean(editor.value.trim()));output.classList.remove('hidden');editor.classList.add('hidden');$('edit-output').textContent='Hariri matokeo';$('output-note').textContent='Maandishi yaliyohaririwa — si tafsiri iliyozalishwa na injini.';state.output=editor.value;persist(KEYS.output,state.output);audit('Edited output','Output edited manually');}
  });
  function changeTextSize(delta){state.textSize=Math.max(12,Math.min(24,state.textSize+delta));source.style.fontSize=state.textSize+'px';persist(KEYS.textSize,state.textSize);}
  ['source-smaller','settings-smaller'].forEach(id=>$(id).addEventListener('click',()=>changeTextSize(-1)));
  ['source-larger','settings-larger'].forEach(id=>$(id).addEventListener('click',()=>changeTextSize(1)));
  source.style.fontSize=state.textSize+'px';updateCounts();

  // General text utilities.
  function detectLanguage(text) {
    if(!text.trim()) return 'Hakuna maandishi ya kuchambua.';
    if(/[\u0600-\u06FF]/.test(text)) return 'Inaonekana kutumia alfabeti ya Kiarabu. Hii si utambuzi wa lugha uliothibitishwa.';
    if(/[\u0900-\u097F]/.test(text)) return 'Inaonekana kutumia Devanagari. Hii si utambuzi wa lugha uliothibitishwa.';
    if(/[ñ¿¡áéíóúü]/i.test(text)) return 'Inaweza kuwa Kihispania au lugha nyingine ya Kilatini; utambuzi huu ni wa makadirio.';
    const sw=(text.match(/\b(na|ya|kwa|ni|hii|hiyo|katika|sana|habari|asante|lakini|wa|za|kuwa)\b/gi)||[]).length;
    const en=(text.match(/\b(the|and|is|are|you|this|that|with|for|have|hello|thank)\b/gi)||[]).length;
    if(sw>en && sw>0)return 'Huenda ni Kiswahili (makadirio ya maneno ya kawaida).';
    if(en>0)return 'Huenda ni Kiingereza (makadirio ya maneno ya kawaida).';
    return 'Lugha haijatambuliwa kwa uhakika. Chagua mwenyewe.';
  }
  $('detect-language').addEventListener('click',()=>{const result=detectLanguage(source.value);if($('source-language').value==='auto' && /Huenda ni Kiswahili/.test(result)) $('source-language').value='sw'; else if($('source-language').value==='auto' && /Kiingereza/.test(result)) $('source-language').value='en';status(result);});
  $('format-text').addEventListener('click',()=>{source.value=source.value.replace(/\r\n?/g,'\n').split('\n').map(line=>line.replace(/[ \t]+$/g,'')).join('\n').replace(/\n{3,}/g,'\n\n').trim();updateCounts();status('Nafasi na mistari zimesawazishwa.');});
  $('download-txt').addEventListener('click',()=>{if(!source.value.trim()){status('Hakuna maandishi ya kupakua.');return;}download('manar-source.txt',source.value);audit('Downloaded source text');});
  async function readFile(file, target, feedback) {
    if(!file)return;
    const allowed=/\.(txt|md|csv|json|srt|vtt|html|xml)$/i;
    if(!allowed.test(file.name)){if(feedback)feedback.textContent='Aina hii ya faili haijawezeshwa. Tumia TXT, MD, CSV, JSON, SRT, VTT, HTML au XML.';toast('Aina ya faili haijawezeshwa.');return;}
    if(file.size>5*1024*1024){if(feedback)feedback.textContent='Faili ni kubwa kuliko kikomo cha 5 MB.';return;}
    try{const text=await file.text();target.value=text;if(feedback)feedback.textContent=`Imepakiwa: ${file.name} (${file.size.toLocaleString()} bytes)`;audit('Imported file',file.name);toast(`Faili ${file.name} limeingizwa.`);}
    catch{if(feedback)feedback.textContent='Imeshindikana kusoma faili hili.';}
  }
  $('quick-file').addEventListener('change',e=>readFile(e.target.files?.[0],source,$('status-message')));
  $('document-file').addEventListener('change',e=>readFile(e.target.files?.[0],$('document-preview'),$('file-feedback')));
  const uploadZone=document.querySelector('.upload-zone');
  uploadZone.addEventListener('dragover',e=>{e.preventDefault();uploadZone.classList.add('drag-over');});
  uploadZone.addEventListener('dragleave',()=>uploadZone.classList.remove('drag-over'));
  uploadZone.addEventListener('drop',e=>{e.preventDefault();uploadZone.classList.remove('drag-over');readFile(e.dataTransfer?.files?.[0],$('document-preview'),$('file-feedback'));});
  $('send-doc-to-translator').addEventListener('click',()=>{source.value=$('document-preview').value;updateCounts();showView('translator');status('Maandishi yamehamishiwa kwenye translator.');});
  $('download-doc').addEventListener('click',()=>{const text=$('document-preview').value;if(!text.trim()){toast('Hakuna maudhui ya kupakua.');return;}download('manar-document.txt',text);});
  $('segment-doc').addEventListener('click',()=>{const text=$('document-preview').value;const segments=text.split(/(?<=[.!?؟。])\s+|\n+/).map(s=>s.trim()).filter(Boolean);const list=$('segment-output');list.replaceChildren();if(!segments.length){list.textContent='Hakuna sentensi za kugawa.';return;}const h=document.createElement('p');h.textContent=`${segments.length} vipande`;list.append(h);segments.slice(0,500).forEach((s,i)=>{const p=document.createElement('p');p.textContent=`${i+1}. ${s}`;list.append(p);});audit('Segmented document',`${segments.length} segments`);});

  // Glossary.
  $('glossary-form').addEventListener('submit',e=>{
    e.preventDefault();const term=$('glossary-term').value.trim(),meaning=$('glossary-meaning').value.trim(),context=$('glossary-context').value.trim();
    if(!term||!meaning)return;
    const duplicate=state.glossary.some(x=>x.term.toLocaleLowerCase()===term.toLocaleLowerCase());
    if(duplicate&&!confirm('Istilahi hii ipo tayari. Uongeze nyingine yenye jina lilelile?'))return;
    state.glossary.unshift({id:cryptoId(),term,meaning,context,createdAt:new Date().toISOString()});
    if(!persist(KEYS.glossary,state.glossary))return;e.target.reset();renderGlossary();renderAdminStats();audit('Added glossary term',term);toast('Istilahi imehifadhiwa.');
  });
  $('glossary-search').addEventListener('input',renderGlossary);
  function renderGlossary(){
    const list=$('glossary-list');if(!list)return;list.replaceChildren();
    const q=($('glossary-search')?.value||'').toLocaleLowerCase();
    const items=state.glossary.filter(x=>`${x.term} ${x.meaning} ${x.context||''}`.toLocaleLowerCase().includes(q));
    if(!items.length){const empty=document.createElement('div');empty.className='empty-state';empty.textContent=state.glossary.length?'Hakuna istilahi zinazolingana.':'Bado hakuna istilahi. Ongeza istilahi ya kwanza hapo juu.';list.append(empty);return;}
    items.forEach(item=>{
      const row=document.createElement('div');row.className='glossary-entry';const content=document.createElement('div');const term=document.createElement('strong');term.textContent=item.term;const meaning=document.createElement('span');meaning.textContent=item.meaning+(item.context?` · ${item.context}`:'');content.append(term,meaning);
      const actions=document.createElement('div');const copy=document.createElement('button');copy.textContent='Tumia kwenye chanzo';copy.addEventListener('click',()=>{source.value+=(source.value?' ':'')+item.term;updateCounts();showView('translator');toast('Istilahi imeongezwa kwenye chanzo.');});
      const remove=document.createElement('button');remove.textContent='Ondoa';remove.setAttribute('aria-label',`Ondoa ${item.term}`);remove.addEventListener('click',()=>{state.glossary=state.glossary.filter(x=>x.id!==item.id);persist(KEYS.glossary,state.glossary);renderGlossary();renderAdminStats();audit('Removed glossary term',item.term);});
      actions.append(copy,remove);row.append(content,actions);list.append(row);
    });
  }
  $('export-glossary').addEventListener('click',()=>{const csv=[['term','meaning','context','createdAt'],...state.glossary.map(x=>[x.term,x.meaning,x.context||'',x.createdAt||''])].map(row=>row.map(escCsv).join(',')).join('\r\n');download('manar-glossary.csv',csv,'text/csv;charset=utf-8');});

  // Translation memory.
  $('memory-form').addEventListener('submit',e=>{
    e.preventDefault();const sourceText=$('memory-source').value.trim(),targetText=$('memory-target').value.trim(),pair=$('memory-pair').value.trim()||'unspecified';
    if(!sourceText||!targetText)return;
    state.memory.unshift({id:cryptoId(),source:sourceText,target:targetText,pair,createdAt:new Date().toISOString()});
    if(!persist(KEYS.memory,state.memory))return;e.target.reset();$('memory-pair').value=pair;renderMemory();renderAdminStats();audit('Added translation memory entry',pair);toast('Translation memory imehifadhiwa.');
  });
  $('memory-search').addEventListener('input',renderMemory);
  function renderMemory(){
    const list=$('memory-list');if(!list)return;list.replaceChildren();const q=($('memory-search')?.value||'').toLocaleLowerCase();
    const items=state.memory.filter(x=>`${x.source} ${x.target} ${x.pair}`.toLocaleLowerCase().includes(q));
    if(!items.length){const empty=document.createElement('div');empty.className='empty-state';empty.textContent=state.memory.length?'Hakuna matokeo ya utafutaji.':'Translation memory bado haina entries.';list.append(empty);return;}
    items.forEach(item=>{const row=document.createElement('div');row.className='glossary-entry';const c=document.createElement('div');const a=document.createElement('strong');a.textContent=item.source;const b=document.createElement('span');b.textContent=`${item.pair} · ${item.target}`;c.append(a,b);const actions=document.createElement('div');const use=document.createElement('button');use.textContent='Tumia chanzo';use.addEventListener('click',()=>{source.value=item.source;updateCounts();showView('translator');toast('Chanzo kimehamishwa.');});const del=document.createElement('button');del.textContent='Ondoa';del.addEventListener('click',()=>{state.memory=state.memory.filter(x=>x.id!==item.id);persist(KEYS.memory,state.memory);renderMemory();renderAdminStats();audit('Removed memory entry',item.pair);});actions.append(use,del);row.append(c,actions);list.append(row);});
  }
  $('export-memory').addEventListener('click',()=>download('manar-translation-memory.json',JSON.stringify(state.memory,null,2),'application/json'));
  $('clear-memory').addEventListener('click',()=>{if(!confirm('Ufute translation memory yote?'))return;state.memory=[];persist(KEYS.memory,state.memory);renderMemory();renderAdminStats();audit('Cleared translation memory');});
  $('import-memory').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{const data=JSON.parse(await file.text());if(!Array.isArray(data)||data.some(x=>typeof x.source!=='string'||typeof x.target!=='string'))throw Error('format');
      state.memory=[...data.map(x=>({id:cryptoId(),source:x.source,target:x.target,pair:String(x.pair||'imported'),createdAt:x.createdAt||new Date().toISOString()})),...state.memory].slice(0,10000);
      persist(KEYS.memory,state.memory);renderMemory();renderAdminStats();audit('Imported memory',file.name);toast('Translation memory imeingizwa.');
    }catch{toast('JSON si sahihi. Inahitaji array ya source/target.');}e.target.value='';
  });

  // QA checks: mechanical checks only, no claim of semantic correctness.
  function runQA(src,tgt,opts={numbers:true,placeholders:true,tags:true,length:false}){
    const issues=[];
    if(!src.trim()||!tgt.trim())issues.push({ok:false,title:'Maandishi hayajakamilika',detail:'Weka source na target ili ukaguzi uwe na maana.'});
    if(src.trim()&&tgt.trim()){
      if(opts.numbers){const nums=s=>s.match(/\b\d+(?:[.,:/-]\d+)*%?\b/g)||[];const a=nums(src),b=nums(tgt);if(JSON.stringify(a)!==JSON.stringify(b))issues.push({ok:false,title:'Namba zinatofautiana',detail:`Chanzo: ${a.join(', ')||'hakuna'} · Tafsiri: ${b.join(', ')||'hakuna'}`});else issues.push({ok:true,title:'Namba zinafanana',detail:`Namba zilizopatikana: ${a.join(', ')||'hakuna'}`});}
      if(opts.placeholders){const re=/\{\{?[\w.-]+\}?\}|%\d*\$?[sdif]|:\w+|\$\{[^}]+\}/g;const a=src.match(re)||[],b=tgt.match(re)||[];if(JSON.stringify(a.sort())!==JSON.stringify(b.sort()))issues.push({ok:false,title:'Placeholders hazifanani',detail:`Chanzo: ${a.join(', ')||'hakuna'} · Tafsiri: ${b.join(', ')||'hakuna'}`});else issues.push({ok:true,title:'Placeholders zinafanana',detail:`Placeholders: ${a.join(', ')||'hakuna'}`});}
      if(opts.tags){const tags=s=>(s.match(/<\/?[a-z][^>]*?>/gi)||[]).map(x=>x.replace(/\s+/g,' ').trim());const a=tags(src),b=tags(tgt);if(JSON.stringify(a)!==JSON.stringify(b))issues.push({ok:false,title:'HTML tags zinatofautiana',detail:`Chanzo: ${a.join(' ')||'hakuna'} · Tafsiri: ${b.join(' ')||'hakuna'}`});else issues.push({ok:true,title:'HTML tags zinafanana',detail:`Tags: ${a.length}`});}
      if(opts.length){const ratio=tgt.length/Math.max(1,src.length);if(ratio<.35||ratio>2.8)issues.push({ok:false,title:'Tofauti kubwa ya urefu',detail:`Target ni ${(ratio*100).toFixed(0)}% ya urefu wa source. Hii ni tahadhari tu.`});else issues.push({ok:true,title:'Urefu uko ndani ya kikomo',detail:`Target ni ${(ratio*100).toFixed(0)}% ya urefu wa source.`});}
    }
    return issues;
  }
  function renderQA(target,issues){
    target.replaceChildren();
    issues.forEach(issue=>{const row=document.createElement('div');row.className='qa-item';const icon=document.createElement('span');icon.className='qa-icon'+(issue.ok?' good':'');icon.textContent=issue.ok?'✓':'!';const content=document.createElement('div');const title=document.createElement('strong');title.textContent=issue.title;const detail=document.createElement('p');detail.textContent=issue.detail;content.append(title,detail);row.append(icon,content);target.append(row);});
    if(!issues.length)target.textContent='Hakuna issues zilizopatikana.';
    audit('Ran quality checks',`${issues.filter(x=>!x.ok).length} warnings`);
  }
  $('run-qa').addEventListener('click',()=>renderQA($('qa-results'),runQA($('qa-source').value,$('qa-target').value,{numbers:$('qa-numbers').checked,placeholders:$('qa-placeholders').checked,tags:$('qa-tags').checked,length:$('qa-length').checked})));

  // Subtitle parsing and validation.
  function subtitleTimeToMs(value){const m=value.trim().replace('.',',').match(/^(?:(\d{1,2}):)?(\d{2}):(\d{2})[,.](\d{1,3})$/);if(!m)return null;return (((Number(m[1]||0)*60+Number(m[2]))*60+Number(m[3]))*1000+Number((m[4]+'00').slice(0,3)));}
  function validateSubtitles(text){
    const lines=text.replace(/\r/g,'').split('\n');const blocks=text.replace(/\r/g,'').trim().split(/\n\s*\n/).filter(Boolean);const issues=[];let cues=0,previousStart=-1;
    if(!text.trim())return [{ok:false,title:'Hakuna subtitles',detail:'Bandika maudhui ya SRT/VTT kwanza.'}];
    if(/^WEBVTT/.test(text.trim())){issues.push({ok:true,title:'VTT header ipo',detail:'Faili linaanza na WEBVTT.'});}
    blocks.forEach((block,i)=>{
      if(/^WEBVTT/.test(block.trim()))return;
      const time=block.match(/((?:\d{1,2}:)?\d{2}:\d{2}[,.]\d{1,3})\s*-->\s*((?:\d{1,2}:)?\d{2}:\d{2}[,.]\d{1,3})/);
      if(!time){issues.push({ok:false,title:`Block ${i+1}: muda haujatambulika`,detail:'Inatarajiwa HH:MM:SS,mmm --> HH:MM:SS,mmm.'});return;}
      cues++;const start=subtitleTimeToMs(time[1]),end=subtitleTimeToMs(time[2]);
      if(start===null||end===null||end<=start)issues.push({ok:false,title:`Cue ${i+1}: muda si sahihi`,detail:'Muda wa mwisho lazima uwe baada ya muda wa kuanza.'});
      else {if(start<previousStart)issues.push({ok:false,title:`Cue ${i+1}: mpangilio wa muda`,detail:'Cue hii inaanza kabla ya cue iliyotangulia.'});previousStart=start;}
      if(!block.slice(block.indexOf(time[0])+time[0].length).trim())issues.push({ok:false,title:`Cue ${i+1}: maandishi hayapo`,detail:'Cue haina maandishi ya subtitle.'});
    });
    if(cues)issues.unshift({ok:true,title:`${cues} cues zimetambuliwa`,detail:'Ukaguzi wa kimuundo tu; si tathmini ya tafsiri.'});
    if(!issues.length)issues.push({ok:true,title:'Hakuna tatizo la wazi',detail:'Muundo wa subtitle unaonekana sawa.'});
    return issues;
  }
  $('validate-subtitles').addEventListener('click',()=>renderQA($('subtitle-results'),validateSubtitles($('subtitle-input').value)));
  $('download-subtitles').addEventListener('click',()=>{const text=$('subtitle-input').value;if(!text.trim()){toast('Hakuna subtitle za kupakua.');return;}download('manar-subtitles.srt',text.replace(/^WEBVTT[^\n]*\n/i,'').replace(/(\d{2}:\d{2}:\d{2})\.(\d{3})/g,'$1,$2'));audit('Downloaded subtitles');});
  $('clean-subtitles').addEventListener('click',()=>{const el=$('subtitle-input');el.value=el.value.replace(/\r\n?/g,'\n').replace(/[ \t]+$/gm,'').replace(/\n{3,}/g,'\n\n').trim()+'\n';toast('Nafasi na mistari zimesafishwa.');});

  // Text tools.
  let utilityResult='';
  function transformText(op,text){
    switch(op){
      case 'uppercase':return text.toLocaleUpperCase();
      case 'lowercase':return text.toLocaleLowerCase();
      case 'titlecase':return text.toLocaleLowerCase().replace(/(^|[\s([{])([\p{L}\p{N}])/gu,(_,a,b)=>a+b.toLocaleUpperCase());
      case 'trim':return text.replace(/\r\n?/g,'\n').split('\n').map(s=>s.replace(/\s+/g,' ').trim()).join('\n').replace(/\n{3,}/g,'\n\n').trim();
      case 'dedupe':{const seen=new Set();return text.split(/\r?\n/).filter(line=>{const key=line.trim().toLocaleLowerCase();if(!key||seen.has(key))return false;seen.add(key);return true;}).join('\n');}
      case 'sort':return text.split(/\r?\n/).filter(Boolean).sort((a,b)=>a.localeCompare(b,undefined,{sensitivity:'base'})).join('\n');
      case 'sentences':return text.split(/(?<=[.!?؟。])\s+|\n+/).map(s=>s.trim()).filter(Boolean).map((s,i)=>`${i+1}. ${s}`).join('\n');
      case 'wordcount':return `Herufi: ${text.length}\nManeno: ${(text.trim().match(/\S+/g)||[]).length}\nMistari: ${text?text.split(/\r?\n/).length:0}\nSentensi (makadirio): ${(text.match(/[.!?؟。]+(?=\s|$)/g)||[]).length}`;
      case 'reverse':return text.split(/\r?\n/).reverse().join('\n');
      case 'download':if(!text.trim())return 'Hakuna maandishi ya kupakua.';download('manar-text-tools.txt',text);return 'Faili la maandishi limepakuliwa.';
      default:return text;
    }
  }
  document.querySelectorAll('[data-textop]').forEach(btn=>btn.addEventListener('click',()=>{
    utilityResult=transformText(btn.dataset.textop,$('utility-input').value);$('utility-result').textContent=utilityResult; audit('Used text tool',btn.dataset.textop);
  }));
  $('use-utility-result').addEventListener('click',()=>{if(!utilityResult.trim()){toast('Endesha zana kwanza.');return;}source.value=utilityResult;updateCounts();showView('translator');toast('Matokeo yamewekwa kwenye chanzo.');});

  // Project management.
  function projectStatusLabel(status){return ({Planning:'Inapangwa','In progress':'Inaendelea',Review:'Mapitio',Completed:'Imekamilika'})[status]||status;}
  function renderProjects(){
    const list=$('project-list');if(!list)return;list.replaceChildren();
    const q=$('project-search').value.toLocaleLowerCase(),filter=$('project-filter').value;
    const items=state.projects.filter(p=>`${p.name} ${p.description||''} ${p.source} ${p.target}`.toLocaleLowerCase().includes(q)&&(filter==='all'||p.status===filter));
    $('project-total').textContent=state.projects.length;
    $('project-active').textContent=state.projects.filter(p=>p.status==='In progress').length;
    $('project-done').textContent=state.projects.filter(p=>p.status==='Completed').length;
    $('project-tasks').textContent=state.projects.reduce((n,p)=>n+Number(p.tasks||0),0).toLocaleString();
    if(!items.length){const empty=document.createElement('div');empty.className='empty-state';empty.textContent=state.projects.length?'Hakuna miradi inayolingana na utafutaji.':'Bado hakuna mradi. Bonyeza “Mradi mpya” kuanza.';list.append(empty);return;}
    items.forEach(p=>{
      const card=document.createElement('article');card.className='project-card';
      const title=document.createElement('h3');title.textContent=p.name;
      const pills=document.createElement('div');pills.className='project-meta';
      const statusPill=document.createElement('span');statusPill.className='pill '+(p.status==='Completed'?'success':p.status==='Review'?'warning':'');statusPill.textContent=projectStatusLabel(p.status);
      const pair=document.createElement('span');pair.className='pill';pair.textContent=`${langName(p.source)} → ${langName(p.target)}`;pills.append(statusPill,pair);
      const desc=document.createElement('p');desc.textContent=p.description||'Hakuna maelezo yaliyoongezwa.';
      const meta=document.createElement('p');meta.textContent=`Kazi/segments: ${Number(p.tasks||0).toLocaleString()} · Mwisho: ${p.due||'Haijawekwa'}`;
      const actions=document.createElement('div');actions.className='project-actions';
      const edit=document.createElement('button');edit.className='secondary-button';edit.textContent='Hariri';edit.addEventListener('click',()=>openProjectDialog(p));
      const next=document.createElement('button');next.className='secondary-button';next.textContent='Badili hali';next.addEventListener('click',()=>{const statuses=['Planning','In progress','Review','Completed'];p.status=statuses[(statuses.indexOf(p.status)+1)%statuses.length];persist(KEYS.projects,state.projects);renderProjects();audit('Changed project status',`${p.name}: ${p.status}`);});
      const del=document.createElement('button');del.className='danger-button';del.textContent='Futa';del.addEventListener('click',()=>{if(!confirm(`Ufute mradi “${p.name}”?`))return;state.projects=state.projects.filter(x=>x.id!==p.id);persist(KEYS.projects,state.projects);renderProjects();renderAdminStats();audit('Deleted project',p.name);});
      actions.append(edit,next,del);card.append(title,pills,desc,meta,actions);list.append(card);
    });
  }
  $('project-search').addEventListener('input',renderProjects);$('project-filter').addEventListener('change',renderProjects);
  function openProjectDialog(project=null){
    $('project-form').reset();$('project-id').value=project?.id||'';
    $('project-dialog-title').textContent=project?'Hariri mradi':'Mradi mpya';
    $('project-name').value=project?.name||'';$('project-source').value=project?.source||'en';$('project-target').value=project?.target||'sw';
    $('project-status').value=project?.status||'Planning';$('project-due').value=project?.due||'';
    $('project-description').value=project?.description||'';$('project-task-count').value=project?.tasks??0;
    if(typeof $('project-dialog').showModal==='function')$('project-dialog').showModal();else toast('Browser hii haiauni project dialog.');
    $('project-name').focus();
  }
  $('new-project').addEventListener('click',()=>openProjectDialog());$('admin-new-project').addEventListener('click',()=>openProjectDialog());
  $('close-project-dialog').addEventListener('click',()=>$('project-dialog').close());$('cancel-project').addEventListener('click',()=>$('project-dialog').close());
  $('project-form').addEventListener('submit',e=>{
    e.preventDefault();const id=$('project-id').value;
    const p={id:id||cryptoId(),name:$('project-name').value.trim(),source:$('project-source').value,target:$('project-target').value,status:$('project-status').value,due:$('project-due').value,description:$('project-description').value.trim(),tasks:Number($('project-task-count').value)||0,updatedAt:new Date().toISOString()};
    if(!p.name){toast('Weka jina la mradi.');return;}
    if(id){const index=state.projects.findIndex(x=>x.id===id);if(index>=0)state.projects[index]={...state.projects[index],...p};audit('Updated project',p.name);}
    else{p.createdAt=p.updatedAt;state.projects.unshift(p);audit('Created project',p.name);}
    persist(KEYS.projects,state.projects);$('project-dialog').close();renderProjects();renderAdminStats();toast('Mradi umehifadhiwa.');
  });


  // Translator directory, organizations, and client job intake. All records remain local to this browser.
  const safeDate = value => value ? String(value) : '';
  function formValue(id){return $(id)?.value?.trim() || '';}
  function addCardText(parent, tag, text, className=''){
    const el=document.createElement(tag); if(className)el.className=className;el.textContent=text;parent.append(el);return el;
  }
  function renderTranslators(){
    const list=$('translator-list');if(!list)return;list.replaceChildren();
    const q=formValue('translator-search').toLocaleLowerCase(), filter=$('translator-filter').value;
    const items=state.translators.filter(x=>(filter==='all'||x.availability===filter)&&`${x.name} ${x.nativeLanguage} ${x.otherLanguages} ${x.specialty} ${x.experience}`.toLocaleLowerCase().includes(q));
    $('translator-total').textContent=state.translators.length;
    $('translator-native').textContent=state.translators.filter(x=>x.nativeLanguage).length;
    $('translator-available').textContent=state.translators.filter(x=>x.availability==='Available').length;
    $('translator-pairs').textContent=state.translators.reduce((n,x)=>n+1+(x.otherLanguages?x.otherLanguages.split(/[,;]+/).filter(Boolean).length:0),0);
    if(!items.length){addCardText(list,'div',state.translators.length?'Hakuna wasifu unaolingana.':'Hakuna wasifu bado. Sajili mtafsiri wa kwanza.','empty-state');return;}
    items.forEach(person=>{
      const card=document.createElement('article');card.className='person-card';
      const top=document.createElement('div');top.className='person-top';const identity=document.createElement('div');
      addCardText(identity,'h3',person.name);addCardText(identity,'p',person.contact,'person-contact');
      const badge=document.createElement('span');badge.className='pill '+(person.availability==='Available'?'success':person.availability==='Busy'?'warning':'');badge.textContent=person.availability;top.append(identity,badge);card.append(top);
      const tags=document.createElement('div');tags.className='project-meta';[['Native',person.nativeLanguage],['Languages',person.otherLanguages],['Specialty',person.specialty],['Experience',person.experience]].forEach(([k,v])=>{const pill=document.createElement('span');pill.className='pill';pill.textContent=`${k}: ${v}`;tags.append(pill);});card.append(tags);
      if(person.bio)addCardText(card,'p',person.bio,'person-description');
      const actions=document.createElement('div');actions.className='project-actions';
      const edit=document.createElement('button');edit.className='secondary-button';edit.textContent='Hariri';edit.addEventListener('click',()=>openTranslatorForm(person));
      const createJob=document.createElement('button');createJob.className='secondary-button';createJob.textContent='Pendekeza kazi';createJob.addEventListener('click',()=>{resetJobForm();$('job-client').value=person.name;$('job-contact').value=person.contact;$('job-title').value=`Kazi ya ${person.specialty.toLocaleLowerCase()}`;$('job-source-language').value=person.nativeCode||'en';$('job-target-language').value='sw';showView('jobinbox');$('job-client').focus();});
      const del=document.createElement('button');del.className='danger-button';del.textContent='Ondoa';del.addEventListener('click',()=>{if(!confirm(`Ondoa wasifu wa ${person.name}?`))return;state.translators=state.translators.filter(x=>x.id!==person.id);persist(KEYS.translators,state.translators);renderTranslators();renderAdminStats();audit('Removed translator profile',person.name);});
      actions.append(edit,createJob,del);card.append(actions);list.append(card);
    });
  }
  function resetTranslatorForm(){ $('translator-form').reset();$('translator-id').value='';$('translator-availability').value='Available';}
  function openTranslatorForm(person){
    resetTranslatorForm();if(person){$('translator-id').value=person.id;$('translator-name').value=person.name;$('translator-contact').value=person.contact;$('translator-native-language').value=person.nativeCode||'';$('translator-other-languages').value=person.otherLanguages;$('translator-specialty').value=person.specialty;$('translator-experience').value=person.experience;$('translator-availability').value=person.availability;$('translator-bio').value=person.bio||'';}
    $('translator-name').focus();
  }
  $('new-translator-profile').addEventListener('click',()=>openTranslatorForm());
  $('cancel-translator-edit').addEventListener('click',resetTranslatorForm);
  $('translator-form').addEventListener('submit',e=>{
    e.preventDefault();const id=formValue('translator-id');
    const person={id:id||cryptoId(),name:formValue('translator-name'),contact:formValue('translator-contact'),nativeCode:$('translator-native-language').value,nativeLanguage:langName($('translator-native-language').value),otherLanguages:formValue('translator-other-languages'),specialty:$('translator-specialty').value,experience:$('translator-experience').value,availability:$('translator-availability').value,bio:formValue('translator-bio'),updatedAt:new Date().toISOString()};
    if(!person.name||!person.contact||!person.nativeCode||!person.otherLanguages){toast('Jaza jina, mawasiliano, lugha ya asili na lugha nyingine.');return;}
    if(id){state.translators=state.translators.map(x=>x.id===id?{...x,...person}:x);audit('Updated translator profile',person.name);}else{person.createdAt=person.updatedAt;state.translators.unshift(person);audit('Created translator profile',person.name);}
    if(persist(KEYS.translators,state.translators)){resetTranslatorForm();renderTranslators();renderAdminStats();toast('Wasifu wa mtafsiri umehifadhiwa kwenye kifaa hiki.');}
  });
  $('translator-search').addEventListener('input',renderTranslators);$('translator-filter').addEventListener('change',renderTranslators);

  function renderOrganizations(){
    const list=$('organization-list');if(!list)return;list.replaceChildren();const q=formValue('organization-search').toLocaleLowerCase();
    const items=state.organizations.filter(x=>`${x.name} ${x.type} ${x.country} ${x.services} ${x.email}`.toLocaleLowerCase().includes(q));
    if(!items.length){addCardText(list,'div',state.organizations.length?'Hakuna mashirika yanayolingana.':'Hakuna mashirika yaliyosajiliwa bado.','empty-state');return;}
    items.forEach(org=>{
      const card=document.createElement('article');card.className='person-card';const top=document.createElement('div');top.className='person-top';const identity=document.createElement('div');addCardText(identity,'h3',org.name);addCardText(identity,'p',`${org.type} · ${org.country||'Eneo halijawekwa'}`,'person-contact');top.append(identity);const badge=document.createElement('span');badge.className='pill';badge.textContent=`${state.jobs.filter(j=>j.organizationId===org.id).length} kazi`;top.append(badge);card.append(top);
      addCardText(card,'p',`${org.contact?org.contact+' · ':''}${org.email}`,'person-contact');if(org.services)addCardText(card,'p',`Huduma: ${org.services}`,'person-description');if(org.notes)addCardText(card,'p',org.notes,'person-description');
      const actions=document.createElement('div');actions.className='project-actions';const job=document.createElement('button');job.className='secondary-button';job.textContent='Pokea kazi';job.addEventListener('click',()=>{resetJobForm();refreshOrganizationOptions();$('job-organization').value=org.id;$('job-client').value=org.name;$('job-contact').value=org.email;showView('jobinbox');$('job-title').focus();});
      const edit=document.createElement('button');edit.className='secondary-button';edit.textContent='Hariri';edit.addEventListener('click',()=>openOrganizationForm(org));
      const del=document.createElement('button');del.className='danger-button';del.textContent='Ondoa';del.addEventListener('click',()=>{if(!confirm(`Ondoa shirika ${org.name}? Kazi zilizopo zitabaki na taarifa za mteja kama zilivyo.`))return;state.organizations=state.organizations.filter(x=>x.id!==org.id);persist(KEYS.organizations,state.organizations);renderOrganizations();refreshOrganizationOptions();renderAdminStats();audit('Removed organization',org.name);});
      actions.append(job,edit,del);card.append(actions);list.append(card);
    });
  }
  function resetOrganizationForm(){$('organization-form').reset();$('organization-id').value='';}
  function openOrganizationForm(org){resetOrganizationForm();if(org){$('organization-id').value=org.id;$('organization-name').value=org.name;$('organization-type').value=org.type;$('organization-contact').value=org.contact||'';$('organization-email').value=org.email;$('organization-country').value=org.country||'';$('organization-services').value=org.services||'';$('organization-notes').value=org.notes||'';}$('organization-name').focus();}
  $('organization-form').addEventListener('submit',e=>{
    e.preventDefault();const id=formValue('organization-id');const org={id:id||cryptoId(),name:formValue('organization-name'),type:$('organization-type').value,contact:formValue('organization-contact'),email:formValue('organization-email'),country:formValue('organization-country'),services:formValue('organization-services'),notes:formValue('organization-notes'),updatedAt:new Date().toISOString()};
    if(!org.name||!org.email){toast('Weka jina la shirika na mawasiliano.');return;}
    if(id){state.organizations=state.organizations.map(x=>x.id===id?{...x,...org}:x);audit('Updated organization',org.name);}else{org.createdAt=org.updatedAt;state.organizations.unshift(org);audit('Added organization',org.name);}
    if(persist(KEYS.organizations,state.organizations)){resetOrganizationForm();renderOrganizations();refreshOrganizationOptions();renderAdminStats();toast('Shirika limehifadhiwa.');}
  });
  $('cancel-organization-edit').addEventListener('click',resetOrganizationForm);
  $('organization-search').addEventListener('input',renderOrganizations);
  $('export-organizations').addEventListener('click',()=>{const csv=[['name','type','contact','email','country','services','notes'],...state.organizations.map(x=>[x.name,x.type,x.contact,x.email,x.country,x.services,x.notes])].map(row=>row.map(escCsv).join(',')).join('\r\n');download('manar-organizations.csv',csv,'text/csv;charset=utf-8');});
  function refreshOrganizationOptions(){
    const select=$('job-organization');if(!select)return;const current=select.value;select.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent='Mteja mpya / hajatajwa';select.append(empty);
    state.organizations.forEach(org=>{const option=document.createElement('option');option.value=org.id;option.textContent=org.name;select.append(option);});
    if(state.organizations.some(x=>x.id===current))select.value=current;
  }
  function resetJobForm(){ $('job-form').reset();$('job-id').value='';$('job-status').value='Pending review';$('job-words').value='0';refreshOrganizationOptions(); }
  function renderJobs(){
    const list=$('job-list');if(!list)return;list.replaceChildren();const q=formValue('job-search').toLocaleLowerCase(),filter=$('job-filter').value;
    const items=state.jobs.filter(j=>(filter==='all'||j.status===filter)&&`${j.title} ${j.client} ${j.contact} ${j.sourceLabel} ${j.targetLabel} ${j.type} ${j.description}`.toLocaleLowerCase().includes(q));
    $('job-total').textContent=state.jobs.length;$('job-pending').textContent=state.jobs.filter(x=>x.status==='Pending review').length;$('job-accepted').textContent=state.jobs.filter(x=>['Accepted','Assigned','In progress','Review'].includes(x.status)).length;$('job-completed').textContent=state.jobs.filter(x=>x.status==='Completed').length;
    refreshOrganizationOptions();
    if(!items.length){addCardText(list,'div',state.jobs.length?'Hakuna kazi zinazolingana.':'Inbox haina kazi bado. Pokea kazi kwa kutumia fomu hapo juu.','empty-state');return;}
    items.forEach(job=>{
      const card=document.createElement('article');card.className='person-card';const top=document.createElement('div');top.className='person-top';const identity=document.createElement('div');addCardText(identity,'h3',job.title);addCardText(identity,'p',`${job.client} · ${job.contact}`,'person-contact');const pill=document.createElement('span');pill.className='pill '+(job.status==='Completed'?'success':job.status==='Rejected'?'':'warning');pill.textContent=job.status;top.append(identity,pill);card.append(top);
      const meta=document.createElement('div');meta.className='project-meta';[[`${job.sourceLabel} → ${job.targetLabel}`],[job.type],[`${Number(job.words||0).toLocaleString()} maneno`],[job.deadline?`Mwisho: ${job.deadline}`:'Hakuna deadline']].forEach(([v])=>{const el=document.createElement('span');el.className='pill';el.textContent=v;meta.append(el);});card.append(meta);if(job.description)addCardText(card,'p',job.description,'person-description');
      const statusSelect=document.createElement('select');statusSelect.className='inline-status';['Pending review','Accepted','Assigned','In progress','Review','Completed','Rejected'].forEach(st=>{const op=document.createElement('option');op.value=st;op.textContent=st;statusSelect.append(op);});statusSelect.value=job.status;statusSelect.setAttribute('aria-label',`Hali ya ${job.title}`);statusSelect.addEventListener('change',()=>{job.status=statusSelect.value;job.updatedAt=new Date().toISOString();persist(KEYS.jobs,state.jobs);renderJobs();renderAdminStats();audit('Changed job status',`${job.title}: ${job.status}`);});
      const actions=document.createElement('div');actions.className='project-actions';const edit=document.createElement('button');edit.className='secondary-button';edit.textContent='Hariri';edit.addEventListener('click',()=>openJobForm(job));const makeProject=document.createElement('button');makeProject.className='secondary-button';makeProject.textContent='Tengeneza mradi';makeProject.addEventListener('click',()=>{const exists=state.projects.some(x=>x.jobId===job.id);if(exists){toast('Mradi wa kazi hii upo tayari.');return;}const project={id:cryptoId(),jobId:job.id,name:job.title,source:job.source,target:job.target,status:job.status==='Completed'?'Completed':'Planning',due:job.deadline,description:`Mteja: ${job.client}. ${job.description||''}`,tasks:Number(job.words)||0,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};state.projects.unshift(project);persist(KEYS.projects,state.projects);renderProjects();renderAdminStats();audit('Created project from incoming job',job.title);toast('Mradi umeundwa kutokana na kazi.');});
      const del=document.createElement('button');del.className='danger-button';del.textContent='Futa';del.addEventListener('click',()=>{if(!confirm(`Futa kazi ${job.title}?`))return;state.jobs=state.jobs.filter(x=>x.id!==job.id);persist(KEYS.jobs,state.jobs);renderJobs();renderAdminStats();audit('Deleted incoming job',job.title);});
      actions.append(edit,makeProject,del);card.append(statusSelect,actions);list.append(card);
    });
  }
  function openJobForm(job){resetJobForm();if(job){$('job-id').value=job.id;refreshOrganizationOptions();$('job-organization').value=job.organizationId||'';$('job-client').value=job.client;$('job-contact').value=job.contact;$('job-title').value=job.title;$('job-source-language').value=job.source;$('job-target-language').value=job.target;$('job-type').value=job.type;$('job-words').value=job.words;$('job-deadline').value=job.deadline||'';$('job-status').value=job.status;$('job-description').value=job.description||'';}$('job-title').focus();}
  $('job-form').addEventListener('submit',e=>{
    e.preventDefault();const id=formValue('job-id'),orgId=$('job-organization').value;
    const job={id:id||cryptoId(),organizationId:orgId,client:formValue('job-client'),contact:formValue('job-contact'),title:formValue('job-title'),source:$('job-source-language').value,target:$('job-target-language').value,sourceLabel:langName($('job-source-language').value),targetLabel:langName($('job-target-language').value),type:$('job-type').value,words:Number($('job-words').value)||0,deadline:safeDate($('job-deadline').value),status:$('job-status').value,description:formValue('job-description'),updatedAt:new Date().toISOString()};
    if(!job.client||!job.contact||!job.title){toast('Jaza jina la mteja, mawasiliano na kichwa cha kazi.');return;}
    if(job.source===job.target){toast('Lugha ya chanzo na lengwa lazima zitofautiane.');return;}
    if(id){state.jobs=state.jobs.map(x=>x.id===id?{...x,...job}:x);audit('Updated incoming job',job.title);}else{job.createdAt=job.updatedAt;state.jobs.unshift(job);audit('Received translation job',job.title);}
    if(persist(KEYS.jobs,state.jobs)){resetJobForm();renderJobs();renderAdminStats();toast('Kazi imepokelewa na kuhifadhiwa kwenye inbox ya ndani.');}
  });
  $('cancel-job-edit').addEventListener('click',resetJobForm);
  $('job-search').addEventListener('input',renderJobs);$('job-filter').addEventListener('change',renderJobs);
  $('export-jobs').addEventListener('click',()=>{const csv=[['title','client','contact','source','target','type','words','deadline','status','description'],...state.jobs.map(x=>[x.title,x.client,x.contact,x.sourceLabel,x.targetLabel,x.type,x.words,x.deadline,x.status,x.description])].map(row=>row.map(escCsv).join(',')).join('\r\n');download('manar-incoming-jobs.csv',csv,'text/csv;charset=utf-8');});

  // History, admin metrics and local audit.
  function setHistoryEnabled(enabled){state.historyEnabled=enabled;persist(KEYS.historyEnabled,enabled);$('history-enabled').checked=enabled;$('history-enabled-settings').checked=enabled;renderHistory();toast(enabled?'Historia imewashwa.':'Historia imezimwa.');}
  $('history-enabled').addEventListener('change',e=>setHistoryEnabled(e.target.checked));
  $('history-enabled-settings').addEventListener('change',e=>setHistoryEnabled(e.target.checked));
  function renderHistory(){
    $('history-enabled').checked=state.historyEnabled;const list=$('history-list');list.replaceChildren();
    if(!state.historyEnabled){list.className='timeline empty-state';list.textContent='Historia imezimwa. Iwashe ili kuhifadhi matukio yajayo.';return;}
    if(!state.history.length){list.className='timeline empty-state';list.textContent='Hakuna historia iliyohifadhiwa bado.';return;}
    list.className='timeline';state.history.forEach(item=>{const row=document.createElement('div');row.className='timeline-item';const dot=document.createElement('span');dot.className='timeline-dot';const content=document.createElement('div');const title=document.createElement('strong');title.textContent=item.action;const detail=document.createElement('p');detail.textContent=`${item.detail||''} · ${new Date(item.at).toLocaleString()}`;content.append(title,detail);row.append(dot,content);list.append(row);});
  }
  $('clear-history').addEventListener('click',()=>{if(!confirm('Ufute historia iliyohifadhiwa?'))return;state.history=[];persist(KEYS.history,state.history);renderHistory();toast('Historia imefutwa.');});
  function renderAdminStats(){
    if(!$('admin-projects'))return;
    $('admin-projects').textContent=state.projects.length;$('admin-terms').textContent=state.glossary.length;$('admin-memory').textContent=state.memory.length;$('admin-events').textContent=state.audit.length;
    $('admin-pending-jobs').textContent=state.jobs.filter(x=>x.status==='Pending review').length;
    $('admin-translators').textContent=state.translators.length;$('admin-organizations').textContent=state.organizations.length;
  }
  function renderAudit(){
    const list=$('audit-list');if(!list)return;list.replaceChildren();
    if(!state.audit.length){list.className='timeline empty-state';list.textContent='Hakuna matukio ya audit bado.';return;}
    list.className='timeline';
    state.audit.slice(0,30).forEach(item=>{const row=document.createElement('div');row.className='timeline-item';const dot=document.createElement('span');dot.className='timeline-dot';const content=document.createElement('div');const title=document.createElement('strong');title.textContent=item.action;const p=document.createElement('p');p.textContent=`${item.detail||''} · ${new Date(item.at).toLocaleString()}`;content.append(title,p);row.append(dot,content);list.append(row);});
  }
  $('clear-audit').addEventListener('click',()=>{if(!confirm('Ufute audit log?'))return;state.audit=[];persist(KEYS.audit,state.audit);renderAudit();renderAdminStats();});
  function renderAdminLanguages(){
    const list=$('admin-language-list');if(!list)return;list.replaceChildren();
    languageOptions.forEach(lang=>{const row=document.createElement('div');row.className='language-check';const dot=document.createElement('span');dot.className='pill warning';dot.textContent='UI';const content=document.createElement('div');const strong=document.createElement('strong');strong.textContent=lang.name;const small=document.createElement('small');small.textContent='Injini haijathibitishwa';content.append(strong,small);row.append(dot,content);list.append(row);});
  }
  function exportAll(){
    const backup={product:'MANAR Language Studio',formatVersion:3,exportedAt:new Date().toISOString(),projects:state.projects,memory:state.memory,glossary:state.glossary,history:state.history,audit:state.audit,historyEnabled:state.historyEnabled,translators:state.translators,organizations:state.organizations,jobs:state.jobs};
    download('manar-workspace-backup.json',JSON.stringify(backup,null,2),'application/json');audit('Exported workspace backup');
  }
  $('admin-export-data').addEventListener('click',exportAll);$('settings-export').addEventListener('click',exportAll);
  $('import-backup').addEventListener('change',async e=>{
    const file=e.target.files?.[0];if(!file)return;
    try{
      const data=JSON.parse(await file.text());
      if(![2,3].includes(data.formatVersion)||!Array.isArray(data.projects)||!Array.isArray(data.glossary)||!Array.isArray(data.memory))throw Error('Invalid backup');
      if(!confirm('Import itabadilisha miradi, glossary, memory na historia ya sasa. Endelea?'))return;
      state.projects=data.projects;state.glossary=data.glossary;state.memory=data.memory;state.history=Array.isArray(data.history)?data.history:[];state.historyEnabled=data.historyEnabled===true;state.audit=Array.isArray(data.audit)?data.audit:[];state.translators=Array.isArray(data.translators)?data.translators:[];state.organizations=Array.isArray(data.organizations)?data.organizations:[];state.jobs=Array.isArray(data.jobs)?data.jobs:[];
      persist(KEYS.projects,state.projects);persist(KEYS.glossary,state.glossary);persist(KEYS.memory,state.memory);persist(KEYS.history,state.history);persist(KEYS.historyEnabled,state.historyEnabled);persist(KEYS.audit,state.audit);persist(KEYS.translators,state.translators);persist(KEYS.organizations,state.organizations);persist(KEYS.jobs,state.jobs);
      renderProjects();renderGlossary();renderMemory();renderAdminStats();renderAudit();toast('Backup imeingizwa.');
    }catch{toast('Backup si sahihi au haiendani na formatVersion 2.');}finally{e.target.value='';}
  });
  $('clear-local-data').addEventListener('click',()=>{
    if(!confirm('Hii itafuta miradi, glossary, memory, historia na audit log kwenye browser hii. Haiwezi kurejeshwa bila backup.'))return;
    state.projects=[];state.glossary=[];state.memory=[];state.history=[];state.audit=[];state.translators=[];state.organizations=[];state.jobs=[];
    [[KEYS.projects,state.projects],[KEYS.glossary,state.glossary],[KEYS.memory,state.memory],[KEYS.history,state.history],[KEYS.audit,state.audit],[KEYS.translators,state.translators],[KEYS.organizations,state.organizations],[KEYS.jobs,state.jobs]].forEach(([k,v])=>persist(k,v));
    renderProjects();renderGlossary();renderMemory();renderHistory();renderAudit();renderAdminStats();renderTranslators();renderOrganizations();renderJobs();toast('Data ya ndani imefutwa.');
  });
  $('profile-button').addEventListener('click',()=>toast('Hii ni workspace ya local demo. Akaunti na uthibitishaji wa server bado havipo.'));

  // Initialize views and empty states.
  renderProjects();renderMemory();renderGlossary();renderHistory();renderAdminStats();renderAudit();renderAdminLanguages();renderTranslators();renderOrganizations();renderJobs();refreshOrganizationOptions();showView('translator');
})();
