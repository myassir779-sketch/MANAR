# Phase 1 test checklist

Automated tests can be run with Node.js 18+ using `npm test`; syntax checks use `npm run check`. No third-party packages are needed.

## Automated tests
- [x] HTML contains the core translator controls and accessible status area.
- [x] Cost policy contains the no-unapproved-cost rule.
- [x] Glossary rendering uses textContent rather than user-provided HTML.
- [x] Translation service rejects empty input and identical explicit languages.
- [x] Translation service does not fabricate output while no model is configured.
- [x] Language registry has unique codes and does not claim verified pairs.
- [x] Storage helpers handle valid values, malformed JSON, quota errors, and blocked storage.
- [x] Basic accessible labels, live status and focus style are present.
- [x] Static core assets remain below 100 KB each and no model binary is bundled.
- [x] Language detection/model loader fail closed; no model download is initiated.

## Manual / environment-dependent tests — not run here
- [ ] Open and interact in desktop browser.
- [ ] Open and interact in small mobile viewport.
- [ ] Clipboard on localhost/HTTPS.
- [ ] Full keyboard and screen-reader audit.
- [ ] Cross-browser compatibility, contrast and touch-target audit.
- [ ] Automated external security scan and performance profiling.
- [ ] Real translation integration and quality tests (not applicable until a model is selected).
- [ ] Deployment and live URL verification (not performed).
