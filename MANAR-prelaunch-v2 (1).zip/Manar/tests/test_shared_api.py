import os, tempfile, unittest
from pathlib import Path
import api_server

class SharedApiSecurityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_db, self.old_secret = api_server.DB_PATH, api_server.TOKEN_SECRET
        api_server.DB_PATH = Path(self.tmp.name) / 'test.sqlite3'
        api_server.TOKEN_SECRET = 'test-secret-' * 4
        con = api_server.db(); con.close()
    def tearDown(self):
        api_server.DB_PATH, api_server.TOKEN_SECRET = self.old_db, self.old_secret
        self.tmp.cleanup()
    def test_password_hash_is_salted_and_verifies(self):
        a = api_server.pw_hash('correct horse battery staple')
        b = api_server.pw_hash('correct horse battery staple')
        self.assertNotEqual(a, b)
        self.assertTrue(api_server.pw_verify('correct horse battery staple', a))
        self.assertFalse(api_server.pw_verify('wrong password', a))
    def test_signed_token_round_trip_and_tamper_rejection(self):
        token = api_server.token_for(7, 'client')
        self.assertEqual(api_server.decode_token(token)['uid'], 7)
        self.assertIsNone(api_server.decode_token(token + 'x'))
    def test_database_has_roles_and_jobs_schema(self):
        con = api_server.db()
        tables = {r['name'] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        con.close()
        self.assertTrue({'users','jobs','translator_profiles','audit'}.issubset(tables))

if __name__ == '__main__': unittest.main()
