import test from 'node:test';
import assert from 'node:assert/strict';
import { stat } from 'node:fs/promises';

test('core app assets remain modest and no model binary is bundled', async () => {
  const paths = ['../../index.html', '../../src/app.js', '../../src/styles/main.css'];
  const sizes = await Promise.all(paths.map(async (path) => (await stat(new URL(path, import.meta.url))).size));
  assert.ok(sizes.every((size) => size < 100_000), 'core static assets should each remain below 100 KB');
});
