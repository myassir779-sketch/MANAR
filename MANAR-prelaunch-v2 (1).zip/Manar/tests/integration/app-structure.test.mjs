import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = (path) => readFile(new URL(path, import.meta.url), 'utf8');

test('main page contains key translator controls and accessible status', async () => {
  const html = await read('../../index.html');
  for (const id of ['source-language', 'target-language', 'source-text', 'translation-output', 'copy-output', 'status-message']) {
    assert.ok(html.includes(`id="${id}"`), `missing ${id}`);
  }
  assert.match(html, /aria-live="polite"/);
});

test('cost policy forbids unapproved paid services', async () => {
  const policy = await read('../../COST_POLICY.md');
  assert.match(policy, /Do not incur costs/i);
  assert.match(policy, /leave it disabled/i);
});
