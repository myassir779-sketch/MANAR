import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('workspace exposes project, memory, glossary, QA, subtitle and admin tools', async () => {
  const html = await readFile(new URL('../../index.html', import.meta.url), 'utf8');
  for (const id of ['view-projects','view-memory','view-dictionary','view-quality','view-subtitles','view-texttools','view-admin','project-dialog','import-backup']) {
    assert.match(html, new RegExp(`id="${id}"`), `missing ${id}`);
  }
});

test('client implementation does not claim a connected translation model', async () => {
  const app = await readFile(new URL('../../src/app.js', import.meta.url), 'utf8');
  const translator = await readFile(new URL('../../src/services/translation/translator.js', import.meta.url), 'utf8');
  assert.match(app, /translateText/);
  assert.match(translator, /not available|unavailable|haijaunganishwa/i);
  assert.doesNotMatch(app, /innerHTML\s*=/);
});
