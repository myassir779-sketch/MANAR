import test from 'node:test';
import assert from 'node:assert/strict';
import { translateText } from '../../src/services/translation/translator.js';

test('translation rejects empty input', async () => {
  const result = await translateText({ text: '  ', sourceLanguage: 'en', targetLanguage: 'sw' });
  assert.equal(result.code, 'EMPTY_INPUT');
});

test('translation rejects identical explicit languages', async () => {
  const result = await translateText({ text: 'Hello', sourceLanguage: 'en', targetLanguage: 'en' });
  assert.equal(result.code, 'SAME_LANGUAGE');
});

test('translation never fabricates output when no model is installed', async () => {
  const result = await translateText({ text: 'Hello world', sourceLanguage: 'en', targetLanguage: 'sw' });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'LOCAL_SERVER_UNAVAILABLE');
  assert.match(result.message, /Hakuna maandishi yaliyotumwa kwa huduma ya nje/);
  assert.equal(result.translation, undefined);
});
