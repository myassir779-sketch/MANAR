import test from 'node:test';
import assert from 'node:assert/strict';
import { detectLanguage } from '../../src/services/language-detection/detect-language.js';
import { loadTranslationModel } from '../../src/services/model-loader/model-loader.js';
import { getConnectivityStatus } from '../../src/services/connectivity/connectivity.js';
import { validateSourceText } from '../../src/utils/text.js';

test('language detection is explicitly unavailable rather than guessed', async () => {
  assert.equal((await detectLanguage('Habari dunia')).code, 'DETECTOR_UNAVAILABLE');
  assert.equal((await detectLanguage('  ')).code, 'EMPTY_INPUT');
});

test('model loader does not download an unreviewed model', async () => {
  assert.equal((await loadTranslationModel('candidate-model')).code, 'MODEL_NOT_CONFIGURED');
  assert.equal((await loadTranslationModel('')).code, 'MODEL_ID_REQUIRED');
});

test('connectivity status uses browser status only', () => {
  assert.equal(getConnectivityStatus({ onLine: false }), 'offline');
  assert.equal(getConnectivityStatus({ onLine: true }), 'online');
  assert.equal(getConnectivityStatus({}), 'unknown');
});

test('source text validation enforces empty and size boundaries', () => {
  assert.equal(validateSourceText('  ').code, 'EMPTY_INPUT');
  assert.equal(validateSourceText('hello').ok, true);
  assert.equal(validateSourceText('x'.repeat(5001)).code, 'INPUT_TOO_LONG');
});
