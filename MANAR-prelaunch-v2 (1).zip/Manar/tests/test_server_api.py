import json
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError

import server

class ServerApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.httpd.server_address[1]}'

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=2)

    def test_health_endpoint_reports_engine_state_without_crashing(self):
        with urlopen(self.base + '/api/health', timeout=3) as response:
            self.assertEqual(response.status, 200)
            data = json.loads(response.read())
        self.assertTrue(data['ok'])
        self.assertIn('engineReady', data)
        self.assertIn('installedPairs', data)

    def test_translation_rejects_empty_input(self):
        request = Request(self.base + '/api/translate', data=json.dumps({
            'text': ' ', 'sourceLanguage': 'en', 'targetLanguage': 'sw'
        }).encode(), headers={'Content-Type': 'application/json'}, method='POST')
        with self.assertRaises(HTTPError) as caught:
            urlopen(request, timeout=3)
        self.assertEqual(caught.exception.code, 400)
        payload = json.loads(caught.exception.read())
        self.assertEqual(payload['error'], 'EMPTY_INPUT')

    def test_auto_language_is_not_silently_guessed(self):
        request = Request(self.base + '/api/translate', data=json.dumps({
            'text': 'Hello', 'sourceLanguage': 'auto', 'targetLanguage': 'sw'
        }).encode(), headers={'Content-Type': 'application/json'}, method='POST')
        with self.assertRaises(HTTPError) as caught:
            urlopen(request, timeout=3)
        self.assertEqual(caught.exception.code, 422)
        payload = json.loads(caught.exception.read())
        self.assertEqual(payload['error'], 'DETECTION_UNAVAILABLE')
        self.assertNotIn('translation', payload)

if __name__ == '__main__':
    unittest.main()
