import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('main controls have labels and status feedback is announced', async () => {
  const html = await readFile(new URL('../../index.html', import.meta.url), 'utf8');
  assert.match(html, /aria-label="Lugha ya chanzo"/);
  assert.match(html, /aria-label="Lugha lengwa"/);
  assert.match(html, /aria-live="polite"/);
  assert.match(html, /<main class="main">/);
});

test('stylesheet includes visible keyboard focus treatment', async () => {
  const css = await readFile(new URL('../../src/styles/main.css', import.meta.url), 'utf8');
  assert.match(css, /:focus-visible/);
});
