import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('glossary rendering uses textContent and does not inject user text as HTML', async () => {
  const app = await readFile(new URL('../../src/app.js', import.meta.url), 'utf8');
  assert.match(app, /term\.textContent\s*=\s*item\.term/);
  assert.match(app, /meaning\.textContent\s*=\s*item\.meaning/);
  assert.doesNotMatch(app, /innerHTML\s*=/);
});
