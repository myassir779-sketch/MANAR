import test from 'node:test';
import assert from 'node:assert/strict';
import { LANGUAGES, getLanguage, getLanguageLabel, isVerifiedPair } from '../../src/config/languages.js';

test('language registry has unique codes and labels', () => {
  const codes = LANGUAGES.map((item) => item.code);
  assert.equal(new Set(codes).size, codes.length);
  assert.ok(LANGUAGES.every((item) => item.name && item.code));
});

test('unknown language codes have a safe label', () => {
  assert.equal(getLanguageLabel('xx'), 'xx');
  assert.equal(getLanguage('xx'), null);
});

test('no language pair is falsely marked verified in Phase 1', () => {
  assert.equal(LANGUAGES.some((item) => item.translationReady), false);
  assert.equal(isVerifiedPair('en', 'sw'), false);
});
