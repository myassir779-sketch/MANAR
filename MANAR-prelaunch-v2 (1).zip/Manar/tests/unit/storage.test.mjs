import test from 'node:test';
import assert from 'node:assert/strict';
import { readLocal, writeLocal, removeLocal } from '../../src/services/storage/local-storage.js';

function fakeStorage() {
  const map = new Map();
  return {
    getItem: (key) => map.has(key) ? map.get(key) : null,
    setItem: (key, value) => map.set(key, String(value)),
    removeItem: (key) => map.delete(key)
  };
}

test('storage wrapper writes, reads and removes JSON values', () => {
  const storage = fakeStorage();
  assert.equal(writeLocal('x', { value: 3 }, storage), true);
  assert.deepEqual(readLocal('x', null, storage), { value: 3 });
  assert.equal(removeLocal('x', storage), true);
  assert.equal(readLocal('x', 'fallback', storage), 'fallback');
});

test('storage wrapper safely handles malformed JSON and exceptions', () => {
  const storage = { getItem: () => '{bad json', setItem: () => { throw new Error('quota'); }, removeItem: () => { throw new Error('blocked'); } };
  assert.equal(readLocal('x', 7, storage), 7);
  assert.equal(writeLocal('x', 1, storage), false);
  assert.equal(removeLocal('x', storage), false);
});
